/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package permainancoklat;

/**
 *
 * @author Michael
 */
public class MinimaxRev {
    int baris,kolom;
    
    public MinimaxRev(int baris, int kolom){
        this.baris = baris;
        this.kolom = kolom;
    }
    
    public int prediksiPoinGainMax(int bar, int kol){ //utk sisa baris,kolom tertentu, cari poin max yang bisa di dapat (ex: awalnya baris:4 kolom:6)
        
        if( (bar == 1 && kol != 1) || (kol == 1 && bar != 1) ){ //tinggal motong (baris ato kolom) 1x langsung menang = biar jd sisa 1 blok coklat
            return 1;
        }
        else{
            int pointGain = 0;
            for(int baris = bar; baris>0; baris--){
                for(int kolom= kol; kolom>0; kolom--){
                    int rekursif = Math.max( prediksiPoinGainMax(baris-1,kolom), prediksiPoinGainMax(baris,kolom-1) ); // pilih anak dr rekursif yg ngasilin poin max
                    pointGain += rekursif; // tambahkan semua nilai max dari setiap kasus anaknya
                }
            }
            return pointGain;
        }
    }
    
    public int prediksiPoinGainMin(int bar, int kol){ //utk sisa baris,kolom tertentu, cari poin minimum yg bisa di dapat (ex: awalnya baris:4 kolom:6)
        
        if( (bar == 1 && kol != 1) || (kol == 1 && bar != 1) ){ //kasus pas dapet poin
            return 1;
        }
        else{
            int pointGain = 0;
            for(int baris = bar; baris>0; baris--){
                for(int kolom= kol; kolom>0; kolom--){
                    int rekursif = Math.min( prediksiPoinGainMax(baris-1,kolom), prediksiPoinGainMax(baris,kolom-1) ); // pilih anak dr rekursif yg ngasilin poin min
                    pointGain += rekursif; // tambahkan semua nilai min dari setiap kasus anaknya
                }
            }
            return pointGain;
        }
    }
    
//    public void minimax(int[] pemotongan){
//        
//    }
    
    //Generate semua langkah yang bisa diambil, dan ambil pemotongan yang menghasilkan nilai maximum, dari sisa coklat yang ada
    public int[] langkahKomputer(int baris, int kolom){ // baris kolom ini tuh sesudah di potong oleh user atopun tidak klo melangkah pertama
        int[] res = new int[2]; // sisa baris kolom yang menguntungkan secara max
        res[0] = -1; res[1] = -1;
        
        //sisa baris hasil semua pemotongan baris
        int maxBar = -1; int potongBar = -1;
        for(int i = baris; i>1;i--){
            int coba = prediksiPoinGainMin(i, kolom);
            if(coba > maxBar){
                maxBar = coba;
                potongBar = i+1;
            }
        }
        
        //sisa kolom hasil semua pemotongan kolom
        int maxKol = -1; int potongKol = -1;
        for(int i = kolom; i>1;i--){
            int coba = prediksiPoinGainMin(baris, i);
            if(coba > maxKol){
                maxKol = coba;
                potongKol = i+1;
            }
        }
        
        //cari pemotongan yang paling bagus
        if(maxBar>maxKol){
            res[0]=potongBar; res[1]=0;
        }
        else if(maxKol>maxBar){
            res[0]=0; res[1]=potongKol;
        }
        
        return res;
    }
    
    public int[] sisaCoklatDariPemotongan(int potongBaris, int potongKolom){
        int[] res = new int[2];
        res[0] = 0; res[1] = 0;
        if(potongBaris == 0){
            res[0] = this.baris;
            res[1] = potongKolom;
        }
        else if(potongKolom == 0){
            res[0] = potongBaris;
            res[1] = this.kolom;
        }
        
        return res;
    }
    
    public void setBaris(int baris){
        this.baris = baris;
    }
    
    public void setKolom(int kolom){
        this.kolom = kolom;
    }
    
    public int getBaris(){
        return this.baris;
    }
    
    public int getKolom(){
        return this.kolom;
    }
    
    public boolean isFinished(){
        boolean res = false;
        if( (this.baris == 1 && this.kolom == 1) ){
            res = true;
        }
        
        return res;
    }
}
