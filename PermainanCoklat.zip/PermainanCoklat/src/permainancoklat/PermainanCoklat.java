/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package permainancoklat;

import java.util.Scanner;

/**
 *
 * @author Muhammad Ravi
 */
public class PermainanCoklat {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Set ukuran coklat ");
        System.out.print("Baris coklat (bloknya): ");
        int baris=sc.nextInt();
        System.out.print("Lebar coklat (bloknya): ");
        int kolom=sc.nextInt();
        System.out.println("Mulai duluan: y/n");
        String str=sc.next();
        
        MinimaxRev minimax = new MinimaxRev(baris,kolom);
        
        if(str.equalsIgnoreCase("y")){
            System.out.println("Pemotongan di : ");
            int bar = sc.nextInt(); int kol = sc.nextInt();
            if(bar == 0){ //berarti motong kolom
                minimax.setKolom(kol);
            }
            else if(kol == 0){ //berarti motong baris
                minimax.setBaris(bar);
            }
            while(minimax.getBaris()!=1 || minimax.getKolom()!=1){
                int sisaBaris = minimax.getBaris(); int sisaKolom = minimax.getKolom();
                int[] pemotonganKomp = minimax.langkahKomputer(sisaBaris, sisaKolom);
                System.out.println("Langkah pemotongan Komputer : Baris: "+pemotonganKomp[0]+" Kolom: "+pemotonganKomp[1]);
                if(minimax.isFinished()){
                    System.out.println("Pemenang: Komputer");
                }
                
                System.out.println("Baris tersisa : " + minimax.getBaris() + "Kolom tersisa : " + minimax.getKolom());
                System.out.println("Langkah anda: ");
                bar = sc.nextInt(); kol = sc.nextInt();
                if(bar == 0){ //berarti motong kolom
                    minimax.setKolom(kol);
                }
                else if(kol == 0){ //berarti motong baris
                    minimax.setBaris(bar);
                }
                if(minimax.isFinished()){
                    System.out.println("Pemenang: Player");
                }
            }
            
        }
        else if(str.equalsIgnoreCase("n")){
            while(minimax.getBaris()!=1 || minimax.getKolom()!=1){
                int sisaBaris = minimax.getBaris(); int sisaKolom = minimax.getKolom();
                int[] pemotonganKomp = minimax.langkahKomputer(sisaBaris, sisaKolom);
                System.out.println("Langkah pemotongan Komputer : Baris: "+pemotonganKomp[0]+" Kolom: "+pemotonganKomp[1]);
                if(minimax.isFinished()){
                    System.out.println("Pemenang: Komputer");
                }
                
                System.out.println("Baris tersisa : " + minimax.getBaris() + "Kolom tersisa : " + minimax.getKolom());
                System.out.println("Langkah anda: ");
                int bar = sc.nextInt(); int kol = sc.nextInt();
                if(bar == 0){ //berarti motong kolom
                    minimax.setKolom(kol);
                }
                else if(kol == 0){ //berarti motong baris
                    minimax.setBaris(bar);
                }
                if(minimax.isFinished()){
                    System.out.println("Pemenang: Player");
                }
            }
        }
        else{
            System.out.println("Input salah");
        }
        
    }
     
}
